<?php

interface IWPML_Theme_Plugin_Localization_UI_Strategy {

	public function get_model();
	public function get_template();
}